<form class=""  method="post">
  <label for="tamu">Nama Tamu</label>
  <input type="text" name="nm" ><br>
  <label for="in">Cek In</label>
  <input type="date" name="in"><br>
  <label for="out">Cek Out</label>
  <input type="date" name="out"><br>
  <button type="submit" name="button">Konfirmasi</button>
</form>
<?php
date_default_timezone_set('Asia/Jakarta');
if (isset($_POST['button'])) {
    $hargaPermalam = 250000;
    $IDTrans = rand(589,929900);
    $nama = $_POST['nm'];
    $cekIn = $_POST['in'];
    $cekOut = $_POST['out'];
    $date1 = new DateTime($cekIn);
    $date2 = new DateTime($cekOut);
    $interval = $date2->diff($date1);
    $hitHari = $interval->d;
    $totalBayar = $hargaPermalam*$hitHari;

    echo "=========================================<br>";
    echo "ID Transaksi : <b>#".$IDTrans."</b><br>";
    echo "Nama Tamu :".$nama."<br>";
    echo "Cek In : ".$cekIn."<br>";
    echo "Cek Out: ".$cekOut."<br>";
    echo "Lama Menginap : ".$hitHari." Malam<br>";
    echo "Harga Permalam : Rp. ".number_format($hargaPermalam)."<br>";
    echo "========================================<br>";
    echo "<b>Total Bayar : Rp. ".number_format($totalBayar)."<b>";


}


 ?>
